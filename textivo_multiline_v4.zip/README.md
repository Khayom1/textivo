# Textivo v3
Independent typography studio by Khayom Abdurahmonov.

## Run in Termux
```bash
cd ~/textivo
python -m http.server 8081
```
Open http://127.0.0.1:8081

Includes English/Russian/Tajik UI, rich text selection styling, font/size/color/highlight/letter and word spacing, typing/deleting timing, local project save, undo/redo and HTML/SVG/basic PNG export. Offline cache works after first load on localhost/HTTPS.

Note: PNG export currently uses plain text and basic canvas styling; full rich-text image rendering is a later enhancement. This is an early working build, not a finished commercial editor.


## Ordered multi-line animation
Add independent lines with the **+ Add line** button. Press Enter to start another line. Animation types each line, waits, deletes it, pauses between lines, then proceeds to the next line.
